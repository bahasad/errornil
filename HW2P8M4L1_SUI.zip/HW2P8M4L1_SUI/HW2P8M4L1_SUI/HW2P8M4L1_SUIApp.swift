//
//  HW2P8M4L1_SUIApp.swift
//  HW2P8M4L1_SUI
//
//  Created by Baha Sadyr on 11/2/24.
//

import SwiftUI

@main
struct HW2P8M4L1_SUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
